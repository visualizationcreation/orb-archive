# Tagged content and the stable engine

## Compatibility and provenance

This skill uses the user's recovered Orb Studio tagged v2 format. `scripts/vendor/studio-parser.cjs` contains the parser and inline validator extracted unchanged from `Desktop/ORB Projects/Studio/Orb Studio 8.18.2026/orb-studio.html` on 2026-09-10. `scripts/vendor/placement.cjs`, `scripts/vendor/orb-validate.cjs`, and `placement.md` come from the user's saved `orb2` engine v1.2.1 package in `Desktop/for astra` (the previously extracted copy). These are local user-provided artifacts, not claims about a public current API. Only the parsing/validation functions are retained; no archived plugin is installed or executed.

The engine reads `[ORB]`, `[THREAD]`, `[POINT]`, `[ANGLE]`, and `[SOURCE]` for the generic profile. The original engine also supports IMAGE, MATERIAL, NUMBER, APEX, PORTAL_AXIS, RECORD, RHYME, and POOL. The generic builder intentionally refuses unsupported fields instead of losing them. Extending those richer files requires their actual schema and a matching adapter.

Syntax: explicit closing tags, `key: value`, and `view: |` followed by two-space-indented prose. The renderer parses this into its SUBJECT, BUILD, THREAD, WORLDS, and SOURCES data. Content is separate from renderer code. Do not inject HTML, scripts, new theme fields, or undocumented COURSE blocks into a file and claim the engine uses them.

## Authoring draft

The assistant writes JSON as a local working draft; the user receives the simpler tagged file. Example shape (abbreviated prose here only; actual delivery must be filled):

```json
{
  "template": "generic",
  "expected_points": 2,
  "nBands": 2,
  "anchors": {"apex": "Broadest framing", "subject": "The exact subject", "far": "Farthest relevant comparison", "left": "One side of the comparison"},
  "preferences": {"visual_theme": "metallic ORB over clouds"},
  "orb": {"subject_id": "subject", "subject_label": "A specific claim about the subject", "kind": "reading", "authored": "2026-09-10", "note": "Scope and limitations"},
  "threads": [{"id": "root", "label": "Main exploration", "entry": "subject", "gloss": "What this thread explains"}],
  "points": [
    {"id": "subject", "world": "root", "label": "A specific claim about the subject", "parent": null, "g": 1, "d": 0, "side": 1, "brk": 0.4, "ab": 0, "tags": ["role:framing", "scope:core", "status:explanation"], "view": "Full authored reading goes here.", "angles": [{"label": "A concrete question", "claim": "What specific comparison can clarify this?"}, {"label": "Another angle", "claim": "What observation would distinguish the possibilities?"}]},
    {"id": "detail", "world": "root", "label": "A concrete mechanism explains the observation", "parent": "subject", "g": 0, "d": 0, "side": 1, "brk": 0.5, "ab": 0, "tags": ["role:mechanism", "scope:core", "status:explanation"], "view": "Another full authored reading goes here.", "angles": [{"label": "Test the mechanism", "claim": "What changes if one input changes?"}, {"label": "Locate the limit", "claim": "Where does this explanation stop working?"}]}
  ],
  "sources": []
}
```

`expected_points` is an exact positive integer, not a ceiling. `nBands` is the planned number of meaningful generality bands. Point scores `g`, `d`, `brk` lie in [0,1], `side` is -1 or 1, and `ab` is an integer 0–3. Score meaning as described in placement.md; a score is an authorial judgment, not a measured scientific fact.

**Level correction:** the recovered placement calculator numbers the broadest band 0, while the actual Studio sorts levels descending to put the broadest point at the top. The builder writes `level = nBands - 1 - calculatedBand`. This preserves the intended descent; longitude and anchor removal stay unchanged. Large point counts do not justify inventing meaningless levels.

Point fields accepted in addition to the example: `tier`, `up_alt` (ID array), `refs` (related point ID array), `forward`, `back`, and `frontier` (direction array). A frontier marker needs the explanation of its limit in `view`. `refs` are NOT source IDs. Evidence attaches through source `points`:

```json
{"id":"source-1","title":"Exact source title","url":"https://example.org/actual-page","publisher":"Publisher","date":"2026-09-10","kind":"primary","points":["subject","detail"]}
```

Use an actual verified source URL, never the illustrative URL above. Omit unknown dates. No sources may be appropriate for explicitly authored fictional or format-demonstration content; factual research requires actual evidence or a candid source limitation. Both parser validators run, plus stricter checks for counts, IDs, references, parent cycles, dropped fields, and duplicate keys. Warnings need editorial review; a pass does not prove factual accuracy or pleasant navigation.

```text
node scripts/orbfill.cjs build draft.json topic.orb.txt
node scripts/orbfill.cjs validate topic.orb.txt
node scripts/orbfill.cjs templates
```

Build refuses to overwrite an existing output. Choose a versioned filename for revisions. Output is accompanied by `.validation.json`; warnings remain visible. Work in batches in the JSON for long jobs, save progress, and assemble only when the actual point count equals the requested count. No scripts generate the prose.

## Adding future templates

Add an entry to templates.json with a unique slug, truthful status, label, description, `kind: reading`, `contract: studio-tagged-v2`, and either inline guidance or a linked local guidance file. Mark it available only after a representative output passes the real parser and content review. The generic helper accepts available reading templates with this same contract. A specialized working or rhythm structure needs its richer fields and validation implemented before availability; copying a name into the menu is insufficient.

A structural template changes editorial coverage, meaningful links, tags, and scoring guidance. A skin requires renderer support and must declare its actual renderer identifier separately. New schemas need versioned adapters and import tests. Do not change the generic wire contract to accommodate a planned template. Template selection is retained as a top-level comment in the tagged file and in the draft, not falsely represented as an engine feature.
