# Linked media for ORB Fill

The user prefers lightweight `.orb.txt` files containing links, not embedded media data or portable bundles. Store images, narration, music and video at their actual hosted locations. Keep the generic tagged format and ordinary evidence sources intact. Do not create a new package format, data URLs or base64 assets for routine media-enabled ORBs.

## Existing Studio contract

Studio recognizes SOURCE entries with `kind: image`, `kind: audio`, or `kind: video`. Use the actual direct media URL in `url`, a descriptive title/caption in `title`, and the appropriate credit in `publisher`. Attach one or more existing point IDs through `points`. An audio entry can contain narration or music; identify its purpose in the title. Ordinary web pages, including YouTube watch pages, remain ordinary source links rather than native video previews. No new tags or schema fields are needed.

In the authoring JSON, add a source object with the existing fields `id`, `title`, `url`, `publisher`, `kind`, and `points`. The normal builder exports and validates these entries. Use real supplied or verified media; do not fill fields with example domains and call the asset ready. Reusing a track across points is supported through its points array. This does not imply continuous playback.

## Reliability and limits

- Prefer stable public HTTPS URLs intended for direct media playback. Confirm the destination serves the expected asset, without a login, expired sharing token or HTML viewer page. Retain descriptive captions and creator/licensing attribution supplied with the asset.
- Verify requested media in the actual Studio renderer, including loading and an audible playback check for supplied audio where available. A syntax validator cannot prove that a remote host permits playback or that a browser supports the codec.
- Studio loads remote previews when selected; it displays an original link and a fallback when a preview fails. Changing points stops previous audio/video. It does not yet promise continuous background music, narration autoplay or timeline synchronization.
- Internet access and the media host remain necessary. Do not describe linked ORBs as self-contained or promise links can never break. Do not automatically download and embed media to work around failed links; report the unavailable asset and use a verified replacement only within the user's scope.
- A private album link is not permission to publish personal photos. Use the authorized assets and destination; new media generation, uploading and paid narration follow their respective production requests.

The existing configured local voice and image tools may supply new assets when requested. This linked-media preference concerns delivery, not permission to run those tools or replace existing recordings.
