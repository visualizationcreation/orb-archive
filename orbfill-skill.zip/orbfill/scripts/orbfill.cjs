#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {lex, parseOrb, validate} = require('./vendor/studio-parser.cjs');
const {validateOrb} = require('./vendor/orb-validate.cjs');
const {place} = require('./vendor/placement.cjs');
const catalog = JSON.parse(fs.readFileSync(path.join(__dirname, '../references/templates.json'), 'utf8'));
const fields = {
  ORB: 'subject_id subject_label kind density positions authored note reduction',
  THREAD: 'id label entry gloss cap',
  POINT: 'world id label level lon view parent tier ab up_alt forward back refs tags frontier',
  ANGLE: 'point label claim',
  SOURCE: 'id title url publisher date kind points',
};
const check = (ok, message) => { if (!ok) throw new Error(message); };
function keys(obj, allowed, where) {
  check(obj && typeof obj === 'object' && !Array.isArray(obj), `${where}: expected object`);
  for (const key of Object.keys(obj)) check(allowed.split(' ').includes(key), `${where}: unsupported field ${key}; refusing to discard it`);
}
function text(value, where) {
  check(typeof value === 'string' && value.trim().length > 0, `${where}: needs nonempty text`);
}
function slug(value, where) { check(typeof value === 'string' && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value), `${where}: needs a lowercase slug`); }
function array(value, where) { check(Array.isArray(value), `${where}: expected array`); }
function link(value, where) {
  let url; try { url = new URL(value); } catch { throw new Error(`${where}: invalid URL`); }
  check(['http:', 'https:'].includes(url.protocol) && !url.username && !url.password, `${where}: needs an HTTP(S) URL without credentials`);
}
function inspect(src) {
  const errors = [], warnings = [];
  try {
    const blocks = lex(src);
    for (const b of blocks) {
      check(fields[b.tag], `Unsupported block [${b.tag}] in generic profile`);
      for (const k of Object.keys(b.f)) {
        check(fields[b.tag].split(' ').includes(k), `[${b.tag}]: unsupported field ${k}`);
        check(b.f[k].length === 1, `[${b.tag}]: duplicate key ${k}`);
      }
    }
    check(blocks.filter(b => b.tag === 'ORB').length === 1, 'Expected exactly one ORB block');
    const doc = parseOrb(src), pts = Object.values(doc.WORLDS).flat();
    check(doc.BUILD.kind === 'reading', 'Generic profile supports kind: reading only');
    const unique = (items, name) => {
      const seen = new Set();
      for (const p of items) { slug(p.id, name); check(!seen.has(p.id), `Duplicate ${name}: ${p.id}`); seen.add(p.id); }
      return seen;
    };
    const ids = unique(pts, 'point ID'), threads = unique(doc.THREAD, 'thread ID');
    unique(doc.SOURCES, 'source ID');
    check(Number.isInteger(doc.BUILD.positions) && doc.BUILD.positions === pts.length && pts.length > 0, 'positions does not match the actual point count');
    const byId = new Map(pts.map(p => [p.id, p]));
    for (const p of pts) {
      check(threads.has(p.world), `${p.id}: undeclared thread ${p.world}`);
      check(Number.isInteger(p.ab) && p.ab >= 0 && p.ab <= 3, `${p.id}: ab must be an integer 0–3`);
      for (const ref of [...(p.refs || []), ...(p.upAlt || []), p.parent, p.forward, p.back].filter(Boolean)) {
        check(ids.has(ref), `${p.id}: unknown point ${ref}`);
        check(ref !== p.id, `${p.id}: self reference`);
      }
      for (const tag of p.tags) check(/^[a-z0-9-]+:[^,\s:]+$/i.test(tag), `${p.id}: malformed facet ${tag}`);
      const seen = new Set([p.id]); let parent = p.parent;
      while (parent) { check(!seen.has(parent), `${p.id}: parent cycle`); seen.add(parent); parent = byId.get(parent)?.parent; }
    }
    for (const t of doc.THREAD) check(byId.get(t.entry)?.world === t.id, `${t.id}: entry must belong to this thread`);
    for (const s of doc.SOURCES) {
      link(s.url, s.id); check(s.points.length > 0, `${s.id}: source needs attached points`);
      for (const id of s.points) check(ids.has(id), `${s.id}: unknown point ${id}`);
    }
    for (const validator of [validate, validateOrb]) {
      const result = validator(doc); errors.push(...result.errors); warnings.push(...result.warnings);
    }
    return {errors: [...new Set(errors)], warnings: [...new Set(warnings)], point_count: pts.length, doc};
  } catch (e) { return {errors: [e.message], warnings, point_count: 0}; }
}
function block(tag, obj) {
  const lines = [`[${tag}]`];
  for (const [key, value] of Object.entries(obj)) {
    if (value === undefined) continue;
    if (value === null) { lines.push(`${key}: null`); continue; }
    let s = Array.isArray(value) ? value.join(', ') : String(value);
    s = s.replace(/\r\n?/g, '\n');
    if (s.includes('\n') || key === 'view' || s === '|') lines.push(`${key}: |`, ...s.split('\n').map(l => `  ${l}`));
    else lines.push(`${key}: ${s}`);
  }
  return lines.concat(`[/${tag}]`, '').join('\n');
}
function build(draft) {
  keys(draft, 'template expected_points nBands anchors preferences orb threads points sources', 'draft');
  const template = catalog.templates.find(t => t.id === (draft.template || catalog.default));
  check(template?.status === 'available' && template.contract === 'studio-tagged-v2' && template.kind === 'reading', 'Template unavailable or needs another adapter');
  check(Number.isInteger(draft.expected_points) && draft.expected_points > 0, 'expected_points must be a positive integer');
  array(draft.points, 'points');
  check(draft.points.length === draft.expected_points, `Requested ${draft.expected_points} points, found ${draft.points.length}`);
  check(Number.isInteger(draft.nBands) && draft.nBands > 0 && draft.nBands <= draft.points.length, 'nBands must be between 1 and point count');
  keys(draft.anchors, 'apex subject far left', 'anchors');
  for (const k of ['apex', 'subject', 'far', 'left']) text(draft.anchors[k], `anchor ${k}`);
  keys(draft.orb, fields.ORB.replace('positions ', ''), 'orb');
  check(draft.orb.kind === 'reading', 'Generic builder needs kind: reading');
  array(draft.threads, 'threads'); check(draft.threads.length > 0, 'At least one thread required');
  array(draft.sources, 'sources');
  for (const t of draft.threads) keys(t, fields.THREAD, 'thread');
  for (const s of draft.sources) { keys(s, fields.SOURCE, 'source'); array(s.points, 'source points'); }
  for (const p of draft.points) {
    keys(p, 'id world label parent tier ab up_alt refs forward back frontier tags view angles g d side brk', 'point');
    check(Object.hasOwn(p, 'parent'), `${p.id}: parent must be explicit (ID or null)`);
    for (const k of ['id','world','label','view']) text(p[k], `${p.id}: ${k}`);
    for (const k of ['g', 'd', 'brk']) check(Number.isFinite(p[k]) && p[k] >= 0 && p[k] <= 1, `${p.id}: ${k} must be in [0,1]`);
    check(p.side === 1 || p.side === -1, `${p.id}: side must be -1 or 1`);
    for (const k of ['tags', 'angles', 'refs', 'up_alt', 'frontier']) if (p[k] !== undefined) array(p[k], `${p.id}: ${k}`);
    check(Array.isArray(p.tags) && Array.isArray(p.angles), `${p.id}: tags and angles required`);
    for (const a of p.angles) { keys(a, 'label claim', 'angle'); text(a.label, 'angle label'); text(a.claim, 'angle claim'); }
  }
  const placed = place(draft.points, {nBands: draft.nBands, subjectId: draft.orb.subject_id});
  const fatal = placed.warnings.filter(w => ['band-overfull', 'parents-too-tight'].includes(w.kind));
  check(!fatal.length, `Placement needs revision: ${JSON.stringify(fatal)}`);
  const pointBlocks = placed.points.map(p => {
    check(Number.isFinite(p.lon), `${p.id}: placement did not produce longitude`);
    const out = {};
    for (const key of fields.POINT.split(' ')) {
      if (key === 'level') out[key] = draft.nBands - 1 - p.level;
      else if (p[key] !== undefined) out[key] = p[key];
    }
    return block('POINT', out) + p.angles.map(a => block('ANGLE', {point:p.id, ...a})).join('');
  });
  const src = `# ORB Fill; template: ${template.id}; contract: studio-tagged-v2\n\n` +
    block('ORB', {...draft.orb, positions: draft.points.length}) +
    draft.threads.map(t => block('THREAD', t)).join('') + pointBlocks.join('') +
    draft.sources.map(s => block('SOURCE', s)).join('');
  const report = inspect(src);
  check(report.errors.length === 0, report.errors.join('\n'));
  // Compare authored payload against what the real parser returned.
  const actual = new Map(Object.values(report.doc.WORLDS).flat().map(p => [p.id, p]));
  const canonical = v => String(v).replace(/\r\n?/g, '\n').trim();
  for (const p of draft.points) {
    const q = actual.get(p.id);
    for (const key of ['world','label','view','parent','tier','ab','forward','back']) {
      if (p[key] !== undefined) assert.deepEqual(q[key], typeof p[key] === 'string' ? canonical(p[key]) : p[key], `${p.id}: ${key} lost on import`);
    }
    for (const key of ['tags','refs','up_alt']) if (p[key] !== undefined) assert.deepEqual(q[key === 'up_alt' ? 'upAlt' : key] || [], p[key], `${p.id}: ${key} lost on import`);
    if (p.frontier !== undefined) assert.deepEqual((q.frontier || '').split(',').map(x => x.trim()).filter(Boolean), p.frontier);
    assert.deepEqual(q.angles, p.angles.map(a => ({l:canonical(a.label), f:canonical(a.claim)})), `${p.id}: angles lost on import`);
  }
  for (const [i, source] of draft.sources.entries()) for (const [k,v] of Object.entries(source)) assert.deepEqual(report.doc.SOURCES[i][k], typeof v === 'string' ? canonical(v) : v, `source ${source.id}: ${k} lost`);
  for (const [i, thread] of draft.threads.entries()) for (const [k,v] of Object.entries(thread)) assert.deepEqual(report.doc.THREAD[i][k], canonical(v), `thread ${thread.id}: ${k} lost`);
  const metadata = {subject_id:report.doc.SUBJECT.id, subject_label:report.doc.SUBJECT.label, ...report.doc.BUILD};
  for (const [k,v] of Object.entries(draft.orb)) assert.deepEqual(metadata[k], canonical(v), `orb: ${k} lost`);
  delete report.doc;
  report.placement_warnings = placed.warnings;
  report.template = template.id;
  report.compatibility = 'Recovered Orb Studio 2026-08-18 parser and v2 validators; generic reading profile';
  return {src, report};
}
if (require.main === module) {
  try {
    const [command, input, output] = process.argv.slice(2);
    if (command === 'templates') console.log(JSON.stringify(catalog, null, 2));
    else if (command === 'validate') {
      check(input, 'Provide a .orb.txt file');
      const report = inspect(fs.readFileSync(input, 'utf8')); delete report.doc;
      console.log(JSON.stringify(report, null, 2)); process.exitCode = report.errors.length ? 1 : 0;
    } else if (command === 'build') {
      check(input && output, 'Provide draft.json and output.orb.txt');
      check(!fs.existsSync(output) && !fs.existsSync(output + '.validation.json'), 'Output exists; choose a new versioned filename');
      const result = build(JSON.parse(fs.readFileSync(input, 'utf8')));
      fs.writeFileSync(output, result.src, {encoding:'utf8', flag:'wx'});
      fs.writeFileSync(output + '.validation.json', JSON.stringify(result.report, null, 2) + '\n', {encoding:'utf8', flag:'wx'});
      console.log(JSON.stringify({output, ...result.report}, null, 2));
    } else throw new Error('Usage: orbfill.cjs templates | build draft.json output.orb.txt | validate file.orb.txt');
  } catch (e) { console.error(e.message); process.exitCode = 1; }
}
module.exports = {build, inspect};
