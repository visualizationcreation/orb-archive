---
name: orbfill
description: "Fill a complete ORB with authored content and export a tagged .orb.txt file for an existing ORB engine or Studio. Use for /orbfill, choosing an ORB content template, populating an ORB structure with a requested number of points, or expanding an existing terrain file. Use orb for live exploration and orbprint for building a website."
---

# ORB Fill

Author the content that fills a stable ORB structure. Deliver a populated UTF-8 `.orb.txt` file, with substantive readings, meaningful relationships, placement, facets, and attached evidence. The engine owns rendering, rotation, controls, and visual skins; this skill owns the terrain. A file is the default deliverable, not a website, recording, or publication.

## Choose the structure

Read [templates.json](references/templates.json) and [the file contract](references/file-contract.md). Use a named template already selected by the user. Otherwise show the actually available choices briefly, with **Generic ORB** as the fallback; if no alternative is installed, proceed with Generic and say so. A request to see or select alternatives should receive the available menu before dependent authoring. Ask for the topic if it cannot be inferred.

Separate a subject (what this ORB explores), a content structure (how its points relate), and a visual theme (how the renderer looks). Record a requested visual skin as a preference; do not claim the file activates it without renderer support. Future templates can specify domain coverage, relationships, tag vocabulary, and ordering while preserving the same wire format. Follow the extension rules in the contract. Never advertise planned templates as available or quietly replace an explicitly requested missing template.

Honor an explicit point count. If unspecified, propose a suitable count and proceed with **24 points** as a practical generic starting choice when the subject supports it. Count all `[POINT]` blocks, including the subject and knowledge-floor points; angles and sources do not count. A requested 100-point ORB means 100 completed points, not a 24-point sample and an outline of the rest. There is no skill-imposed maximum. Large jobs may be authored in batches with stable IDs and a saved completion ledger, then assembled into one file. Explain real context, evidence, or renderer limits; never report an incomplete file as full or pad with duplicates to reach a number.

## Fill the terrain

- Author prose directly with the primary assistant model. Do not delegate writing to a local language model unless explicitly requested. Research supplied material and appropriate sources; verify changing or uncertain claims. No invented citations, image URLs, testimony, or evidence.
- Map the complete subject before drafting. Balance major aspects against the user's scope rather than over-weighting earlier examples from chat history. Assign stable IDs, threads, parents, and a brief unique purpose for every point.
- Generic structure descends from broad framing through systems and relationships to concrete mechanisms, examples, and an honest knowledge floor. DOWN can mean finer scale or deeper explanation. A bottom-level question must grow out of that descent and distinguish an actual research frontier from information simply not covered here. Include its established basis, uncertainty, and what could resolve it in the reading.
- Write engaging, precise, independently useful readings, usually 120–220 words when the requested depth warrants it. Shorter readings are appropriate for intentionally compact files; review the validator's under-60-word warning. Replace noun-only labels with informative claims. Give each point two specific, useful angles onward and a small shared vocabulary of facet tags.
- `parent` expresses a real broader explanation; `refs` links related points; `forward` expresses a supported consequence. Course order is a different relationship. Do not manufacture a consequence chain merely to make a spiral.
- Attach sources to the exact points they support. Preserve factual qualifications, cultural attribution, and the boundary between evidence and imagination. In source-limited work, explicitly mark the gap. Images and audio are optional later production, not fake placeholders in a completed content file.

## Build and check the file

Use the documented authoring JSON and bundled helper in [file-contract.md](references/file-contract.md). Score placement against explicit anchors using [placement.md](references/placement.md); the helper calculates coordinates with the recovered engine calculator and converts its band numbering to the Studio's level convention. Do not hand-adjust output coordinates to conceal overcrowding.

1. Write the full content draft and check requested versus authored count. Retain placement anchors and scoring with the draft for future expansion.
2. Run `node scripts/orbfill.cjs build <draft.json> <topic.orb.txt>`. The helper rejects structural errors, verifies content survives the recovered Studio parser, and writes a validation report next to the text file.
3. Review warnings and actual writing. Resolve thin or repetitive readings, meaningless relationships, accidental missing evidence, and crowded placement. At large counts, use meaningful bands and threads; threads alone do not remove global band crowding in the recovered renderer. If one display cannot remain legible, preserve the requested content and identify the limitation. Offer partitioning or a renderer upgrade without silently splitting or reducing the deliverable.
4. Run `node scripts/orbfill.cjs validate <topic.orb.txt>` after any manual edit. For a different supplied engine, inspect its parser and validate with it before promising compatibility. The bundled check proves the recovered Studio contract, not every future renderer or website importer.

Deliver the clickable `.orb.txt` file with its actual point count, selected template, and a short compatibility note. Keep the draft and report available. Never deliver scaffold headings as populated points. When extending an existing file, preserve IDs, readings not being edited, attachments, and links; inspect the complete format first rather than round-tripping unsupported blocks through the generic builder.

## Optional handoffs

Use `orb` for continuing live exploration and `orbprint` for an explicitly requested HTML artifact. Pass the same point IDs, readings, sources, and meaningful links; tagged Studio files and website `orb.json` are different formats requiring an adapter. The ORB Archive Studio at https://visualizationcreation.github.io/orb-archive/studio.html is the intended receiver. Verify its live availability before describing it as deployed. It accepts the generic reading profile; uploaded content stays in the visitor’s browser and is not automatically published. Give the user both the file and the Studio link when verified. Studio visual layouts and finishes do not change the file’s conceptual relationships.

For requested course scripts, preserve the terrain and author a connected ORB Learn or ORB Feel & Experience treatment separately. Feel uses warm second-person guidance, sensory invitations, and an unhurried return. Existing recordings and matching transcripts remain intact on text-only revisions. Audio language and voice choices belong to requested audio production, not this text-only export. A future spiral playback route or skin must use an actual supported engine extension; until then put production preferences in the draft, not invented tags that the parser discards.
